-- MariaDB dump 10.19  Distrib 10.11.7-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u955032989_new
-- ------------------------------------------------------
-- Server version	10.11.7-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'shah@gmail.com','shah@gmail.com','c4ca4238a0b923820dcc509a6f75849b'),
(2,'Dangio','nello.dangiolella.vda@gmail.com','c4ca4238a0b923820dcc509a6f75849b'),
(3,'Fjoralb ','fjoralbdine@hotmail.com','c4ca4238a0b923820dcc509a6f75849b'),
(4,'Onano','filtroilpodcast@gmail.com','ab5b78c4be735ee9cedd699ab3c00fae'),
(5,'Pippo','pippo.vale@gmail.com','e10adc3949ba59abbe56e057f20f883e'),
(6,'Nello','nello.dangiolella@libero.it','25d55ad283aa400af464c76d713c07ad'),
(7,'Anna63','anna@Nna.it','202cb962ac59075b964b07152d234b70'),
(8,'Bruscolino','bbb@gmail.com','202cb962ac59075b964b07152d234b70'),
(9,'massimo','massimo@gmail.com','81dc9bdb52d04dc20036dbd8313ed055'),
(10,'Pier','pier.g.g.nonnis@icloud.com','fb6c3573f2252b9fa553416900c9bf14'),
(11,'onnix','adadaad@gmail.com','202cb962ac59075b964b07152d234b70'),
(12,'Fjoralb Dine','fjoralbdine@icloud.com','906de6f1ae47bf81d011168081c911bf'),
(13,'michele','michele@icloud.com','202cb962ac59075b964b07152d234b70'),
(14,'Mfjejdjw uUHHUUJdiwjdiwj ???????????????????? jhduwifjefheufheuh eufhudfjhuh?????????????? ?????????','yasen.krasen.13+78178@mail.ru','25f9e794323b453885f5181f1b624d0b'),
(15,'gimihay943@facais.com','gimihay943@facais.com','325c9d88c0ed82ede39d5d9a1b8703d9');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Dumping routines for database 'u955032989_new'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-16 15:18:02
